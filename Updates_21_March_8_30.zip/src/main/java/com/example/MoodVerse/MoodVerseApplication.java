package com.example.MoodVerse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoodVerseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoodVerseApplication.class, args);
	}

}

